package models;

import java.io.Serializable;

public class PurchaseModel implements Serializable{
	
}
